// Aryan Hotel - Booking Page JavaScript with FIXED PRICE CALCULATION

// Room prices per night
const roomPrices = {
    single: 2500,
    double: 4000,
    triple: 5500,
    dormitory: 1200
};

// Room names for display
const roomNames = {
    single: 'Single Bed Room',
    double: 'Double Bed Room',
    triple: 'Triple Bed Room',
    dormitory: 'Dormitory Bed'
};

// Booking data
let bookingData = {
    rooms: {
        single: { quantity: 0, total: 0 },
        double: { quantity: 0, total: 0 },
        triple: { quantity: 0, total: 0 },
        dormitory: { quantity: 0, total: 0 }
    },
    dates: {
        checkIn: '',
        checkOut: '',
        nights: 0
    },
    totals: {
        roomTotal: 0,
        tax: 0,
        grandTotal: 0
    }
};

// DOM elements
const checkInInput = document.getElementById('checkIn');
const checkOutInput = document.getElementById('checkOut');

// Set minimum date for check-in to today
const today = new Date().toISOString().split('T')[0];
if (checkInInput) checkInInput.min = today;

// FIXED: Update check-out min date when check-in changes
if (checkInInput) {
    checkInInput.addEventListener('change', function() {
        const checkInDate = new Date(this.value);
        const minCheckOut = new Date(checkInDate);
        minCheckOut.setDate(minCheckOut.getDate() + 1);
        
        if (checkOutInput) {
            checkOutInput.min = minCheckOut.toISOString().split('T')[0];
            
            if (checkOutInput.value && new Date(checkOutInput.value) <= checkInDate) {
                checkOutInput.value = '';
            }
        }
        
        calculateNights();
        updateAllRoomTotals(); // FIXED: Recalculate all room totals
    });
}

if (checkOutInput) {
    checkOutInput.addEventListener('change', function() {
        calculateNights();
        updateAllRoomTotals(); // FIXED: Recalculate all room totals
    });
}

// FIXED: Calculate nights between check-in and check-out
function calculateNights() {
    if (checkInInput && checkOutInput && checkInInput.value && checkOutInput.value) {
        const checkIn = new Date(checkInInput.value);
        const checkOut = new Date(checkOutInput.value);
        const timeDiff = checkOut.getTime() - checkIn.getTime();
        const nights = Math.ceil(timeDiff / (1000 * 3600 * 24));
        
        if (nights > 0) {
            bookingData.dates.nights = nights;
            bookingData.dates.checkIn = checkInInput.value;
            bookingData.dates.checkOut = checkOutInput.value;
            return nights;
        } else {
            bookingData.dates.nights = 0;
            if (nights <= 0 && checkOutInput.value) {
                alert('Check-out date must be after check-in date.');
            }
            return 0;
        }
    }
    return 0;
}

// FIXED: Update individual room quantity and total
function updateRoomQuantity(roomType, quantity) {
    bookingData.rooms[roomType].quantity = quantity;
    
    // FIXED: Calculate total = price per night × nights × quantity
    const nights = bookingData.dates.nights || 0;
    const pricePerNight = roomPrices[roomType];
    bookingData.rooms[roomType].total = pricePerNight * nights * quantity;
    
    // Update individual room total display
    const totalElement = document.getElementById(`${roomType}-total`);
    if (totalElement) {
        totalElement.textContent = bookingData.rooms[roomType].total.toLocaleString();
    }
    
    updateRoomSummary();
}

// FIXED: Update ALL room totals when nights change
function updateAllRoomTotals() {
    const nights = bookingData.dates.nights || 0;
    
    Object.keys(bookingData.rooms).forEach(roomType => {
        const quantity = bookingData.rooms[roomType].quantity;
        const pricePerNight = roomPrices[roomType];
        
        // FIXED: Recalculate total for each room type
        bookingData.rooms[roomType].total = pricePerNight * nights * quantity;
        
        // Update display
        const totalElement = document.getElementById(`${roomType}-total`);
        if (totalElement) {
            totalElement.textContent = bookingData.rooms[roomType].total.toLocaleString();
        }
    });
    
    updateRoomSummary();
}

// Update room summary table and grand total
function updateRoomSummary() {
    let roomTotal = 0;
    let summaryHTML = '';
    
    Object.keys(bookingData.rooms).forEach(roomType => {
        if (bookingData.rooms[roomType].quantity > 0) {
            roomTotal += bookingData.rooms[roomType].total;
            summaryHTML += `
                <tr>
                    <td class="py-2">${roomNames[roomType]}</td>
                    <td class="py-2 text-center">${bookingData.rooms[roomType].quantity}</td>
                    <td class="py-2 text-right">₹${roomPrices[roomType].toLocaleString()}</td>
                    <td class="py-2 text-right">₹${bookingData.rooms[roomType].total.toLocaleString()}</td>
                </tr>
            `;
        }
    });
    
    if (summaryHTML === '') {
        summaryHTML = '<tr><td colspan="4" class="py-4 text-center text-gray-500">No rooms selected</td></tr>';
    }
    
    const summaryElement = document.getElementById('room-summary');
    if (summaryElement) {
        summaryElement.innerHTML = summaryHTML;
    }
    
    const totalElement = document.getElementById('room-total');
    if (totalElement) {
        totalElement.textContent = roomTotal.toLocaleString();
    }
    
    bookingData.totals.roomTotal = roomTotal;
    updateGrandTotal();
}

// Update grand total with tax
function updateGrandTotal() {
    const roomTotal = bookingData.totals.roomTotal;
    const tax = roomTotal * 0.18; // 18% tax
    const grandTotal = roomTotal + tax;
    
    bookingData.totals.tax = tax;
    bookingData.totals.grandTotal = grandTotal;
    
    const taxElement = document.getElementById('total-tax');
    if (taxElement) {
        taxElement.textContent = tax.toLocaleString();
    }
    
    const grandTotalElement = document.getElementById('grand-total');
    if (grandTotalElement) {
        grandTotalElement.textContent = grandTotal.toLocaleString();
    }
}

// Room quantity increase buttons
document.querySelectorAll('.increase-room').forEach(button => {
    button.addEventListener('click', function() {
        const roomType = this.getAttribute('data-room');
        const input = document.querySelector(`.room-quantity[data-room="${roomType}"]`);
        const max = parseInt(input.getAttribute('max'));
        
        if (parseInt(input.value) < max) {
            input.value = parseInt(input.value) + 1;
            updateRoomQuantity(roomType, parseInt(input.value));
        }
    });
});

// Room quantity decrease buttons
document.querySelectorAll('.decrease-room').forEach(button => {
    button.addEventListener('click', function() {
        const roomType = this.getAttribute('data-room');
        const input = document.querySelector(`.room-quantity[data-room="${roomType}"]`);
        
        if (parseInt(input.value) > 0) {
            input.value = parseInt(input.value) - 1;
            updateRoomQuantity(roomType, parseInt(input.value));
        }
    });
});

// Confirm booking button
const confirmBookingBtn = document.getElementById('confirm-booking');
if (confirmBookingBtn) {
    confirmBookingBtn.addEventListener('click', function() {
        // Validate booking
        const hasRooms = Object.values(bookingData.rooms).some(room => room.quantity > 0);
        
        if (!hasRooms) {
            alert('Please select at least one room.');
            return;
        }
        
        if (!bookingData.dates.checkIn || !bookingData.dates.checkOut) {
            alert('Please select check-in and check-out dates.');
            return;
        }
        
        if (bookingData.dates.nights <= 0) {
            alert('Please select valid dates.');
            return;
        }
        
        // Show confirmation
        const confirmMessage = `
Booking Confirmed!

Dates: ${formatDate(bookingData.dates.checkIn)} to ${formatDate(bookingData.dates.checkOut)}
Nights: ${bookingData.dates.nights}
Total Amount: ₹${bookingData.totals.grandTotal.toLocaleString()}

Thank you for booking with Aryan Hotel!
        `;
        
        alert(confirmMessage);
        
        // Optional: Reset form
        // resetBooking();
    });
}

// Format date for display
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-IN', options);
}

// Mobile menu toggle
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const mobileMenu = document.getElementById('mobileMenu');

if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', function() {
        mobileMenu.classList.toggle('hidden');
        const icon = this.querySelector('i');
        if (mobileMenu.classList.contains('hidden')) {
            icon.className = 'fas fa-bars';
        } else {
            icon.className = 'fas fa-times';
        }
    });
}

// Scroll to top
const scrollTopBtn = document.getElementById('scrollTop');
if (scrollTopBtn) {
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            scrollTopBtn.classList.remove('hidden');
            scrollTopBtn.classList.add('flex');
        } else {
            scrollTopBtn.classList.add('hidden');
            scrollTopBtn.classList.remove('flex');
        }
    });
    
    scrollTopBtn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    console.log('Booking page loaded with FIXED price calculation');
    updateRoomSummary();
});
